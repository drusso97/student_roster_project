#  Student Roster Project

This school project processes a string of student data as input and manipulates it to generate a readable format. Additionally, it provides functionality to remove students from the roster based on their ID.

Developed and tested in Xcode. 

All identifying information has been removed from the project. This project is not meant to be used for cheating.
